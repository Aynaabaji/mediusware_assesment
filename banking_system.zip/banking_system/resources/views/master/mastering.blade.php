@include('includes.top')
@include('includes.navbar')
@yield('content')
@include('includes.bottom')
