<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1 class="my-5 current_balance">Current Balance : <?php echo e($currentBalance); ?> /-</h1>
        <h2>Transaction Table</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Transaction Type</th>
                    <th>Amount</th>
                    <th>Fee</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($trn->id); ?></td>
                    <td><?php echo e($trn->user_id); ?></td>
                    <td><?php echo e($trn->transaction_type); ?></td>
                    <td><?php echo e($trn->amount); ?></td>
                    <td><?php echo e($trn->fee); ?></td>
                    <td><?php echo e($trn->date); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
     </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('master.mastering', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/banking_system/resources/views/welcome.blade.php ENDPATH**/ ?>