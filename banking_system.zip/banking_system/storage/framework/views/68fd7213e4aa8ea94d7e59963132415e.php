<?php $__env->startSection('content'); ?>

    <div class="container">
        
        <form action="<?php echo e(route('postWD')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <label for="user_id">User Id:</label>
            <input type="text" step="0.01" id="user_id" name="user_id" required>
            <label for="amount">Amount:</label>
            <input type="number" step="0.01" id="amount" name="amount" required>

            <button type="submit">Withdraw</button>
        </form>
        
        <h2>Withdrawals Table</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Amount</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $withdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($trn->id); ?></td>
                    <td><?php echo e($trn->user_id); ?></td>
                    <td><?php echo e($trn->amount); ?></td>
                    <td><?php echo e($trn->date); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
     </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('master.mastering', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/banking_system/resources/views/pages/withdrawl.blade.php ENDPATH**/ ?>